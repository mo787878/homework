#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_SIZE 100

// ����ջ�ṹ��
typedef struct {
    int data[MAX_SIZE];
    int top;
} Stack;

// ��ʼ��ջ
void initStack(Stack* s) {
    s->top = -1;
}

// �ж�ջ�Ƿ�Ϊ��
int isEmpty(Stack* s) {
    return s->top == -1;
}

// �ж�ջ�Ƿ�����
int isFull(Stack* s) {
    return s->top == MAX_SIZE - 1;
}

// ��ջ����
void push(Stack* s, int value) {
    if (isFull(s)) {
        printf("Stack overflow\n");
        exit(EXIT_FAILURE);
    }
    s->data[++(s->top)] = value;
}

// ��ջ����
int pop(Stack* s) {
    if (isEmpty(s)) {
        printf("Stack underflow\n");
        exit(EXIT_FAILURE);
    }
    return s->data[(s->top)--];
}

// ��ȡջ��Ԫ��
int peek(Stack* s) {
    if (isEmpty(s)) {
        printf("Stack is empty\n");
        exit(EXIT_FAILURE);
    }
    return s->data[s->top];
}

// ��ȡ���������ȼ�
int precedence(char op) {
    if (op == '+' || op == '-')
        return 1;
    if (op == '*' || op == '/')
        return 2;
    return 0;
}

// ִ������
int applyOp(int a, int b, char op) {
    switch (op) {
    case '+': return a + b;
    case '-': return a - b;
    case '*': return a * b;
    case '/': return a / b;
    }
    return 0;
}

// �������ʽ��ֵ
int evaluate(char* exp) {
    Stack values, ops;
    initStack(&values);
    initStack(&ops);

    int i = 0;
    while (exp[i] != '\0') {
        if (isdigit(exp[i])) {
            int val = 0;
            while (isdigit(exp[i])) {
                val = (val * 10) + (exp[i] - '0');
                i++;
            }
            push(&values, val);
            i--;
        }
        else if (exp[i] == '(') {
            push(&ops, exp[i]);
        }
        else if (exp[i] == ')') {
            while (!isEmpty(&ops) && peek(&ops) != '(') {
                int val2 = pop(&values);
                int val1 = pop(&values);
                char op = pop(&ops);
                push(&values, applyOp(val1, val2, op));
            }
            if (!isEmpty(&ops) && peek(&ops) == '(') {
                pop(&ops);
            }
        }
        else if (exp[i] == '+' || exp[i] == '-' || exp[i] == '*' || exp[i] == '/') {
            while (!isEmpty(&ops) && precedence(peek(&ops)) >= precedence(exp[i])) {
                int val2 = pop(&values);
                int val1 = pop(&values);
                char op = pop(&ops);
                push(&values, applyOp(val1, val2, op));
            }
            push(&ops, exp[i]);
        }
        i++;
    }

    while (!isEmpty(&ops)) {
        int val2 = pop(&values);
        int val1 = pop(&values);
        char op = pop(&ops);
        push(&values, applyOp(val1, val2, op));
    }

    return pop(&values);
}

int main() {
    char exp[MAX_SIZE];
    printf("�����������������ʽ��");
    scanf("%s", exp);

    int result = evaluate(exp);
    printf("����ʽ�Ľ���ǣ�%d\n", result);

    return 0;
}