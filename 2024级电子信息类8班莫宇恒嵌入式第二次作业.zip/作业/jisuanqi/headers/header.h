#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#define MAX_SIZE 100
typedef struct {
    int data[MAX_SIZE];
    int top;
} Stack;
void initStack(Stack* s) 
int isEmpty(Stack* s)
int isFull(Stack* s)
void push(Stack* s, int value)
int pop(Stack* s)
int peek(Stack* s)
int precedence(char op)
int applyOp(int a, int b, char op)
int evaluate(char* exp)

