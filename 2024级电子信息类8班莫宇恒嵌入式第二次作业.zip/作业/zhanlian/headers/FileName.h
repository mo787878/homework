#include <stdio.h>
#include <stdlib.h>
typedef struct StackNode {
    int data;
    struct StackNode* next;
} StackNode;
typedef struct Stack {
    StackNode* top;
} Stack;
Stack* createStack()
int isEmpty(Stack* stack)
void push(Stack* stack, int value)
int pop(Stack* stack)
int peek(Stack* stack)
void freeStack(Stack* stack)





