#include <stdio.h>
#include <stdlib.h>

// ����ջ�ڵ�ṹ��
typedef struct StackNode {
    int data;
    struct StackNode* next;
} StackNode;

// ����ջ�ṹ��
typedef struct Stack {
    StackNode* top;
} Stack;

// ��ʼ��ջ
Stack* createStack() {
    Stack* stack = (Stack*)malloc(sizeof(Stack));
    if (stack == NULL) {
        return NULL;
    }
    stack->top = NULL;
    return stack;
}

// �ж�ջ�Ƿ�Ϊ��
int isEmpty(Stack* stack) {
    return stack->top == NULL;
}

// ��ջ����
void push(Stack* stack, int value) {
    StackNode* newNode = (StackNode*)malloc(sizeof(StackNode));
    if (newNode == NULL) {
        return;
    }
    newNode->data = value;
    newNode->next = stack->top;
    stack->top = newNode;
}

// ��ջ����
int pop(Stack* stack) {
    if (isEmpty(stack)) {
        return -1; 
    }
    StackNode* temp = stack->top;
    int value = temp->data;
    stack->top = stack->top->next;
    free(temp);
    return value;
}

// ��ȡջ��Ԫ��
int peek(Stack* stack) {
    if (isEmpty(stack)) {
        return -1;
    }
    return stack->top->data;
}

// �ͷ�ջ�ڴ�
void freeStack(Stack* stack) {
    StackNode* current = stack->top;
    StackNode* next;
    while (current != NULL) {
        next = current->next;
        free(current);
        current = next;
    }
    free(stack);
}

int main() {
    Stack* stack = createStack();

    push(stack, 10);
    push(stack, 20);
    push(stack, 30);

    printf("ջ��Ԫ��: %d\n", peek(stack));
    printf("��ջԪ��: %d\n", pop(stack));
    printf("ջ��Ԫ��: %d\n", peek(stack));

    freeStack(stack);

    return 0;
}