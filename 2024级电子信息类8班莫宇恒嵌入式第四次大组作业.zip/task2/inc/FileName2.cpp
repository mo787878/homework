#include <stdio.h>
#include <stdlib.h>
typedef struct TreeNode {

}TreeNode;
TreeNode* createNode(int data){}
TreeNode* insert(TreeNode* root, int data) {}
TreeNode* search(TreeNode* root, int data){}
TreeNode* findMinNode(TreeNode* node){}
TreeNode* deleteNode(TreeNode* root, int data){}
void inorderTraversal(TreeNode* root){}
void freeTree(TreeNode* root){}
